from fastapi import FastAPI, HTTPException, Depends, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from pathlib import Path
import os
import logging
from typing import Optional, List
from datetime import datetime, timedelta
import json
import jwt
import bcrypt
import uuid
import secrets

# Import models and database
from models import *
from database import db

# Load environment variables
ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Admin credentials and security
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "VIP@dm1n2025!"  # Strong password - change this!
JWT_SECRET_KEY = secrets.token_urlsafe(32)
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = 8

# JWT token functions
def create_admin_token():
    payload = {
        "sub": ADMIN_USERNAME,
        "exp": datetime.utcnow() + timedelta(hours=JWT_EXPIRATION_HOURS),
        "iat": datetime.utcnow(),
        "admin": True
    }
    return jwt.encode(payload, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)

def verify_admin_token(credentials: HTTPAuthorizationCredentials = Depends(HTTPBearer())):
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
        if payload.get("admin") != True:
            raise HTTPException(status_code=401, detail="Invalid admin token")
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

# Create FastAPI app
app = FastAPI(
    title="Premium Subscription Shop API",
    description="SEO-optimized e-commerce platform for premium subscriptions",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Admin authentication routes
@app.post("/api/admin/login")
async def admin_login(credentials: dict):
    """Secure admin login with JWT token"""
    username = credentials.get("username")
    password = credentials.get("password")
    
    if username != ADMIN_USERNAME or password != ADMIN_PASSWORD:
        raise HTTPException(
            status_code=401, 
            detail="Invalid admin credentials"
        )
    
    token = create_admin_token()
    return {
        "success": True,
        "message": "Login successful",
        "token": token,
        "expires_in": JWT_EXPIRATION_HOURS * 3600  # seconds
    }

@app.post("/api/admin/verify")
async def verify_admin_session(admin_data: dict = Depends(verify_admin_token)):
    """Verify admin session is valid"""
    return {
        "success": True,
        "message": "Valid admin session",
        "admin": admin_data.get("sub"),
        "expires": admin_data.get("exp")
    }

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# JWT Configuration
SECRET_KEY = os.getenv("JWT_SECRET", "your-secret-key-here")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Security
security = HTTPBearer()

# Authentication functions
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        return user_id
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))

def generate_uuid() -> str:
    return str(uuid.uuid4())

# Analytics middleware
@app.middleware("http")
async def analytics_middleware(request: Request, call_next):
    # Log page view
    client_ip = request.client.host
    user_agent = request.headers.get("user-agent", "")
    referrer = request.headers.get("referer")
    
    # Generate session ID (simple implementation)
    session_id = request.headers.get("x-session-id", "anonymous")
    
    analytics_data = AnalyticsCreate(
        page_path=str(request.url.path),
        ip_address=client_ip,
        user_agent=user_agent,
        referrer=referrer,
        session_id=session_id
    )
    
    try:
        await db.log_analytics(analytics_data)
    except Exception as e:
        logger.error(f"Error logging analytics: {e}")
    
    response = await call_next(request)
    return response

# Routes

# Authentication Routes
@app.post("/api/auth/register", response_model=AuthResponse)
async def register_user(user_data: UserCreate):
    """Register a new user"""
    try:
        # Check if user already exists
        existing_user = await db.get_user_by_email(user_data.email)
        if existing_user:
            raise HTTPException(status_code=400, detail="User already exists")
        
        # Hash password
        hashed_password = hash_password(user_data.password)
        
        # Create user
        user = User(
            id=generate_uuid(),
            first_name=user_data.first_name,
            last_name=user_data.last_name,
            email=user_data.email,
            password=hashed_password,
            created_at=datetime.utcnow()
        )
        
        created_user = await db.create_user(user)
        
        # Create access token
        access_token = create_access_token(data={"sub": created_user.id})
        
        return AuthResponse(
            success=True,
            message="User registered successfully",
            data=AuthData(
                access_token=access_token,
                token_type="bearer",
                user=UserResponse(
                    id=created_user.id,
                    first_name=created_user.first_name,
                    last_name=created_user.last_name,
                    email=created_user.email,
                    created_at=created_user.created_at
                )
            )
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error registering user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/auth/login", response_model=AuthResponse)
async def login_user(login_data: UserLogin):
    """Login user"""
    try:
        # Get user by email
        user = await db.get_user_by_email(login_data.email)
        if not user:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        # Verify password
        if not verify_password(login_data.password, user.password):
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        # Create access token
        access_token = create_access_token(data={"sub": user.id})
        
        return AuthResponse(
            success=True,
            message="Login successful",
            data=AuthData(
                access_token=access_token,
                token_type="bearer",
                user=UserResponse(
                    id=user.id,
                    first_name=user.first_name,
                    last_name=user.last_name,
                    email=user.email,
                    created_at=user.created_at
                )
            )
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error logging in user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/auth/me", response_model=UserResponse)
async def get_current_user(current_user_id: str = Depends(verify_token)):
    """Get current user info"""
    try:
        user = await db.get_user_by_id(current_user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        return UserResponse(
            id=user.id,
            first_name=user.first_name,
            last_name=user.last_name,
            email=user.email,
            created_at=user.created_at
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting current user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Product Routes
@app.get("/api/products", response_model=PaginatedResponse)
async def get_products(
    category: Optional[str] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    rating: Optional[int] = None,
    sort_by: str = "created_at",
    sort_order: str = "desc",
    page: int = 1,
    per_page: int = 12,
    search: Optional[str] = None
):
    """Get products with filters and pagination"""
    try:
        filters = SearchFilters(
            category=category,
            min_price=min_price,
            max_price=max_price,
            rating=rating,
            sort_by=sort_by,
            sort_order=sort_order,
            page=page,
            per_page=per_page,
            search=search
        )
        
        products = await db.get_products(filters)
        total = await db.get_products_count(filters)
        total_pages = (total + per_page - 1) // per_page
        
        return PaginatedResponse(
            success=True,
            message="Products retrieved successfully",
            data=[product.dict() for product in products],
            total=total,
            page=page,
            per_page=per_page,
            total_pages=total_pages
        )
    except Exception as e:
        logger.error(f"Error getting products: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/products/featured", response_model=ProductResponse)
async def get_featured_products(limit: int = 8):
    """Get featured products"""
    try:
        products = await db.get_featured_products(limit)
        return ProductResponse(
            success=True,
            message="Featured products retrieved successfully",
            data=[product.dict() for product in products]
        )
    except Exception as e:
        logger.error(f"Error getting featured products: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/products/bestsellers", response_model=ProductResponse)
async def get_bestseller_products(limit: int = 8):
    """Get bestseller products"""
    try:
        products = await db.get_bestseller_products(limit)
        return ProductResponse(
            success=True,
            message="Bestseller products retrieved successfully",
            data=[product.dict() for product in products]
        )
    except Exception as e:
        logger.error(f"Error getting bestseller products: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/products/search", response_model=ProductResponse)
async def search_products(q: str, limit: int = 10):
    """Search products"""
    try:
        products = await db.search_products(q, limit)
        return ProductResponse(
            success=True,
            message="Search results retrieved successfully",
            data=[product.dict() for product in products]
        )
    except Exception as e:
        logger.error(f"Error searching products: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/products/{product_id}", response_model=ProductResponse)
async def get_product(product_id: str):
    """Get product by ID"""
    try:
        product = await db.get_product(product_id)
        if not product:
            raise HTTPException(status_code=404, detail="Product not found")
        
        return ProductResponse(
            success=True,
            message="Product retrieved successfully",
            data=product.dict()
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting product: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/products/slug/{slug}", response_model=ProductResponse)
async def get_product_by_slug(slug: str):
    """Get product by slug"""
    try:
        product = await db.get_product_by_slug(slug)
        if not product:
            raise HTTPException(status_code=404, detail="Product not found")
        
        return ProductResponse(
            success=True,
            message="Product retrieved successfully",
            data=product.dict()
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting product by slug: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Admin Product Routes
@app.post("/api/admin/products", response_model=ProductResponse)
async def create_product(product: ProductCreate):
    """Create new product (Admin only)"""
    try:
        new_product = await db.create_product(product)
        return ProductResponse(
            success=True,
            message="Product created successfully",
            data=new_product.dict()
        )
    except Exception as e:
        logger.error(f"Error creating product: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.put("/api/admin/products/{product_id}", response_model=ProductResponse)
async def update_product(product_id: str, product_update: ProductUpdate):
    """Update product (Admin only)"""
    try:
        updated_product = await db.update_product(product_id, product_update)
        if not updated_product:
            raise HTTPException(status_code=404, detail="Product not found")
        
        return ProductResponse(
            success=True,
            message="Product updated successfully",
            data=updated_product.dict()
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating product: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.delete("/api/admin/products/{product_id}", response_model=ProductResponse)
async def delete_product(product_id: str):
    """Delete product (Admin only)"""
    try:
        deleted = await db.delete_product(product_id)
        if not deleted:
            raise HTTPException(status_code=404, detail="Product not found")
        
        return ProductResponse(
            success=True,
            message="Product deleted successfully"
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting product: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# User Routes
@app.post("/api/users/register", response_model=ProductResponse)
async def register_user(user: UserCreate):
    """Register new user"""
    try:
        # Check if user already exists
        existing_user = await db.get_user_by_email(user.email)
        if existing_user:
            raise HTTPException(status_code=400, detail="User already exists")
        
        new_user = await db.create_user(user)
        return ProductResponse(
            success=True,
            message="User registered successfully",
            data=new_user.dict()
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error registering user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/users/login", response_model=ProductResponse)
async def login_user(user_login: UserLogin):
    """Login user"""
    try:
        user = await db.get_user_by_email(user_login.email)
        if not user:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        # TODO: Implement password verification
        
        return ProductResponse(
            success=True,
            message="User logged in successfully",
            data=user.dict()
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error logging in user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/users/{user_id}", response_model=ProductResponse)
async def get_user(user_id: str):
    """Get user by ID"""
    try:
        user = await db.get_user(user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        return ProductResponse(
            success=True,
            message="User retrieved successfully",
            data=user.dict()
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Order Routes
@app.post("/api/orders", response_model=ProductResponse)
async def create_order(order: OrderCreate):
    """Create new order"""
    try:
        new_order = await db.create_order(order)
        return ProductResponse(
            success=True,
            message="Order created successfully",
            data=new_order.dict()
        )
    except Exception as e:
        logger.error(f"Error creating order: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/orders/{order_id}", response_model=ProductResponse)
async def get_order(order_id: str):
    """Get order by ID"""
    try:
        order = await db.get_order(order_id)
        if not order:
            raise HTTPException(status_code=404, detail="Order not found")
        
        return ProductResponse(
            success=True,
            message="Order retrieved successfully",
            data=order.dict()
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting order: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/users/{user_id}/orders", response_model=ProductResponse)
async def get_user_orders(user_id: str):
    """Get user orders"""
    try:
        orders = await db.get_user_orders(user_id)
        return ProductResponse(
            success=True,
            message="User orders retrieved successfully",
            data=[order.dict() for order in orders]
        )
    except Exception as e:
        logger.error(f"Error getting user orders: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.put("/api/orders/{order_id}/status", response_model=ProductResponse)
async def update_order_status(order_id: str, status_update: OrderStatusUpdate):
    """Update order status"""
    try:
        updated = await db.update_order_status(order_id, status_update.status)
        if not updated:
            raise HTTPException(status_code=404, detail="Order not found")
        
        return ProductResponse(
            success=True,
            message="Order status updated successfully"
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating order status: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.put("/api/orders/{order_id}/payment", response_model=ProductResponse)
async def update_payment_status(order_id: str, payment_update: PaymentStatusUpdate):
    """Update payment status"""
    try:
        updated = await db.update_order_payment_status(order_id, payment_update.payment_status)
        if not updated:
            raise HTTPException(status_code=404, detail="Order not found")
        
        return ProductResponse(
            success=True,
            message="Payment status updated successfully"
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating payment status: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Review Routes
@app.post("/api/reviews", response_model=ProductResponse)
async def create_review(review: ReviewCreate):
    """Create new review"""
    try:
        new_review = await db.create_review(review)
        return ProductResponse(
            success=True,
            message="Review created successfully",
            data=new_review.dict()
        )
    except Exception as e:
        logger.error(f"Error creating review: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/products/{product_id}/reviews", response_model=ProductResponse)
async def get_product_reviews(product_id: str, limit: int = 10):
    """Get product reviews"""
    try:
        reviews = await db.get_product_reviews(product_id, limit)
        return ProductResponse(
            success=True,
            message="Product reviews retrieved successfully",
            data=[review.dict() for review in reviews]
        )
    except Exception as e:
        logger.error(f"Error getting product reviews: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Blog Routes
@app.post("/api/admin/blog", response_model=ProductResponse)
async def create_blog_post(blog_post: BlogPostCreate):
    """Create new blog post (Admin only)"""
    try:
        new_post = await db.create_blog_post(blog_post)
        return ProductResponse(
            success=True,
            message="Blog post created successfully",
            data=new_post.dict()
        )
    except Exception as e:
        logger.error(f"Error creating blog post: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/blog", response_model=ProductResponse)
async def get_blog_posts(limit: int = 10, skip: int = 0):
    """Get blog posts"""
    try:
        posts = await db.get_blog_posts(limit, skip)
        return ProductResponse(
            success=True,
            message="Blog posts retrieved successfully",
            data=[post.dict() for post in posts]
        )
    except Exception as e:
        logger.error(f"Error getting blog posts: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/blog/featured", response_model=ProductResponse)
async def get_featured_blog_posts(limit: int = 3):
    """Get featured blog posts"""
    try:
        posts = await db.get_featured_blog_posts(limit)
        return ProductResponse(
            success=True,
            message="Featured blog posts retrieved successfully",
            data=[post.dict() for post in posts]
        )
    except Exception as e:
        logger.error(f"Error getting featured blog posts: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/blog/{post_id}", response_model=ProductResponse)
async def get_blog_post(post_id: str):
    """Get blog post by ID"""
    try:
        post = await db.get_blog_post(post_id)
        if not post:
            raise HTTPException(status_code=404, detail="Blog post not found")
        
        return ProductResponse(
            success=True,
            message="Blog post retrieved successfully",
            data=post.dict()
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting blog post: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/blog/slug/{slug}", response_model=ProductResponse)
async def get_blog_post_by_slug(slug: str):
    """Get blog post by slug"""
    try:
        post = await db.get_blog_post_by_slug(slug)
        if not post:
            raise HTTPException(status_code=404, detail="Blog post not found")
        
        return ProductResponse(
            success=True,
            message="Blog post retrieved successfully",
            data=post.dict()
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting blog post by slug: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Category Routes
@app.post("/api/admin/categories", response_model=ProductResponse)
async def create_category(category: CategoryCreate):
    """Create new category (Admin only)"""
    try:
        new_category = await db.create_category(category)
        return ProductResponse(
            success=True,
            message="Category created successfully",
            data=new_category.dict()
        )
    except Exception as e:
        logger.error(f"Error creating category: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/categories", response_model=ProductResponse)
async def get_categories():
    """Get all categories"""
    try:
        categories = await db.get_categories()
        return ProductResponse(
            success=True,
            message="Categories retrieved successfully",
            data=[category.dict() for category in categories]
        )
    except Exception as e:
        logger.error(f"Error getting categories: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Admin Stock Management Routes
@app.post("/api/admin/stock/set-all-out-of-stock")
async def set_all_out_of_stock(current_user_id: str = Depends(verify_token)):
    """Set all products to out of stock"""
    try:
        result = await db.db.products.update_many(
            {},
            {
                "$set": {
                    "stock_quantity": 0,
                    "status": ProductStatus.OUT_OF_STOCK.value,
                    "updated_at": datetime.utcnow()
                }
            }
        )
        return {
            "success": True,
            "message": f"Successfully set {result.modified_count} products to out of stock",
            "data": {"updated_count": result.modified_count}
        }
    except Exception as e:
        logger.error(f"Error setting all products out of stock: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/admin/stock/set-all-in-stock")
async def set_all_in_stock(
    default_stock: int = 100,
    current_user_id: str = Depends(verify_token)
):
    """Set all products to in stock with default quantity"""
    try:
        result = await db.db.products.update_many(
            {},
            {
                "$set": {
                    "stock_quantity": default_stock,
                    "status": ProductStatus.ACTIVE.value,
                    "updated_at": datetime.utcnow()
                }
            }
        )
        return {
            "success": True,
            "message": f"Successfully set {result.modified_count} products to in stock",
            "data": {"updated_count": result.modified_count, "default_stock": default_stock}
        }
    except Exception as e:
        logger.error(f"Error setting all products in stock: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/admin/stock/set-product-stock")
async def set_product_stock(
    product_id: str,
    stock_quantity: int,
    current_user_id: str = Depends(verify_token)
):
    """Set stock for a specific product"""
    try:
        status = ProductStatus.ACTIVE if stock_quantity > 0 else ProductStatus.OUT_OF_STOCK
        result = await db.db.products.update_one(
            {"id": product_id},
            {
                "$set": {
                    "stock_quantity": stock_quantity,
                    "status": status.value,
                    "updated_at": datetime.utcnow()
                }
            }
        )
        
        if result.modified_count > 0:
            return {
                "success": True,
                "message": f"Successfully updated stock for product {product_id}",
                "data": {"product_id": product_id, "stock_quantity": stock_quantity}
            }
        else:
            raise HTTPException(status_code=404, detail="Product not found")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error setting product stock: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/admin/stock/overview")
async def get_stock_overview(current_user_id: str = Depends(verify_token)):
    """Get stock overview for all products"""
    try:
        pipeline = [
            {
                "$group": {
                    "_id": None,
                    "total_products": {"$sum": 1},
                    "in_stock": {
                        "$sum": {
                            "$cond": [{"$gt": ["$stock_quantity", 0]}, 1, 0]
                        }
                    },
                    "out_of_stock": {
                        "$sum": {
                            "$cond": [{"$eq": ["$stock_quantity", 0]}, 1, 0]
                        }
                    },
                    "total_stock_units": {"$sum": "$stock_quantity"}
                }
            }
        ]
        
        result = await db.db.products.aggregate(pipeline).to_list(length=1)
        if result:
            data = result[0]
            data.pop('_id', None)
            return {
                "success": True,
                "message": "Stock overview retrieved successfully",
                "data": data
            }
        else:
            return {
                "success": True,
                "message": "Stock overview retrieved successfully",
                "data": {
                    "total_products": 0,
                    "in_stock": 0,
                    "out_of_stock": 0,
                    "total_stock_units": 0
                }
            }
    except Exception as e:
        logger.error(f"Error getting stock overview: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/admin/stock/low-stock")
async def get_low_stock_products(
    threshold: int = 10,
    current_user_id: str = Depends(verify_token)
):
    """Get products with low stock"""
    try:
        cursor = db.db.products.find(
            {"stock_quantity": {"$lte": threshold, "$gt": 0}},
            {"id": 1, "name": 1, "stock_quantity": 1, "category": 1, "discounted_price": 1}
        )
        products = await cursor.to_list(length=100)
        return {
            "success": True,
            "message": f"Found {len(products)} products with low stock",
            "data": products
        }
    except Exception as e:
        logger.error(f"Error getting low stock products: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/admin/content")
async def save_content_data(content_data: dict):
    """Save content management data"""
    try:
        success = await db.save_content_data(content_data)
        if success:
            return {
                "success": True,
                "message": "Content data saved successfully",
                "data": content_data
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to save content data")
    except Exception as e:
        logger.error(f"Error saving content data: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/admin/content")
async def get_content_data():
    """Get content management data"""
    try:
        content = await db.get_content_data()
        return {
            "success": True,
            "message": "Content data retrieved successfully",
            "data": content or {}
        }
    except Exception as e:
        logger.error(f"Error getting content data: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Newsletter Routes
@app.post("/api/newsletter", response_model=ProductResponse)
async def subscribe_newsletter(newsletter: NewsletterCreate):
    """Subscribe to newsletter"""
    try:
        subscription = await db.subscribe_newsletter(newsletter)
        return ProductResponse(
            success=True,
            message="Successfully subscribed to newsletter",
            data=subscription.dict()
        )
    except Exception as e:
        logger.error(f"Error subscribing to newsletter: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Contact Routes
@app.post("/api/contact", response_model=ProductResponse)
async def create_contact(contact: ContactCreate):
    """Create contact message"""
    try:
        new_contact = await db.create_contact(contact)
        return ProductResponse(
            success=True,
            message="Contact message sent successfully",
            data=new_contact.dict()
        )
    except Exception as e:
        logger.error(f"Error creating contact: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Secure admin routes - require authentication
@app.delete("/api/admin/products/{product_id}")
async def delete_product_secure(
    product_id: str,
    admin_data: dict = Depends(verify_admin_token)
):
    """Delete a product (Secure Admin Only)"""
    try:
        result = await db.delete_product(product_id)
        if result:
            return {
                "success": True,
                "message": "Product deleted successfully",
                "data": {"deleted": True, "product_id": product_id}
            }
        else:
            raise HTTPException(status_code=404, detail="Product not found")
    except Exception as e:
        logger.error(f"Error deleting product: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.put("/api/admin/products/{product_id}")
async def update_product_secure(
    product_id: str,
    product_data: dict,
    admin_data: dict = Depends(verify_admin_token)
):
    """Update a product (Secure Admin Only)"""
    try:
        # Calculate discount percentage if prices provided
        if 'original_price' in product_data and 'discounted_price' in product_data:
            original = float(product_data['original_price'])
            discounted = float(product_data['discounted_price'])
            if original > 0:
                discount_percentage = round(((original - discounted) / original) * 100)
                product_data['discount_percentage'] = discount_percentage
        
        # Add updated timestamp
        product_data['updated_at'] = datetime.utcnow()
        
        result = await db.update_product(product_id, product_data)
        if result:
            return {
                "success": True,
                "message": "Product updated successfully",
                "data": result
            }
        else:
            raise HTTPException(status_code=404, detail="Product not found")
    except Exception as e:
        logger.error(f"Error updating product: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/admin/categories")
async def create_category(
    category_data: dict,
    admin_data: dict = Depends(verify_admin_token)
):
    """Create a new product category (Secure Admin Only)"""
    try:
        category = {
            "id": category_data.get("slug", category_data.get("name", "").lower().replace(" ", "-")),
            "name": category_data.get("name"),
            "description": category_data.get("description", ""),
            "icon": category_data.get("icon", "📦"),
            "color": category_data.get("color", "blue"),
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
        
        # Save to database (you'll need to add this method to database.py)
        result = await db.create_category(category)
        
        return {
            "success": True,
            "message": "Category created successfully",
            "data": category
        }
    except Exception as e:
        logger.error(f"Error creating category: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/admin/categories")
async def get_categories(admin_data: dict = Depends(verify_admin_token)):
    """Get all categories (Secure Admin Only)"""
    try:
        categories = await db.get_categories()
        
        # Default categories if none exist
        if not categories:
            default_categories = [
                {"id": "ott", "name": "Streaming", "description": "OTT Platforms", "icon": "📺", "color": "red"},
                {"id": "music", "name": "Music", "description": "Music Streaming", "icon": "🎵", "color": "purple"},
                {"id": "vpn", "name": "VPNs", "description": "VPN & Security", "icon": "🔒", "color": "green"},
                {"id": "software", "name": "Software", "description": "Software & Tools", "icon": "💻", "color": "blue"},
                {"id": "professional", "name": "Professional", "description": "Professional Tools", "icon": "⭐", "color": "yellow"},
                {"id": "education", "name": "Education", "description": "Learning Platforms", "icon": "📚", "color": "indigo"},
                {"id": "gaming", "name": "Gaming", "description": "Gaming Services", "icon": "🎮", "color": "pink"},
                {"id": "health", "name": "Health", "description": "Health & Fitness", "icon": "💪", "color": "teal"}
            ]
            return {
                "success": True,
                "message": "Default categories retrieved",
                "data": default_categories
            }
        
        return {
            "success": True,
            "message": "Categories retrieved successfully",
            "data": categories
        }
    except Exception as e:
        logger.error(f"Error getting categories: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")
async def get_analytics_stats():
    """Get analytics statistics (Admin only)"""
    try:
        stats = await db.get_analytics_stats()
        return ProductResponse(
            success=True,
            message="Analytics statistics retrieved successfully",
            data=stats
        )
    except Exception as e:
        logger.error(f"Error getting analytics stats: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Advanced Admin Routes for WooCommerce-level functionality
@app.get("/api/orders")
async def get_all_orders(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    status: Optional[str] = None
):
    """Get all orders with pagination and filtering"""
    try:
        orders = await db.get_orders(page=page, per_page=per_page, status_filter=status)
        return {
            "success": True,
            "message": "Orders retrieved successfully",
            "data": orders
        }
    except Exception as e:
        logger.error(f"Error getting orders: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.put("/api/admin/order-status")
async def update_order_status(
    order_id: str,
    status: str,
    current_user_id: str = Depends(verify_token)
):
    """Update order status"""
    try:
        updated_order = await db.update_order_status(order_id, status)
        if updated_order:
            return {
                "success": True,
                "message": "Order status updated successfully",
                "data": updated_order
            }
        else:
            raise HTTPException(status_code=404, detail="Order not found")
    except Exception as e:
        logger.error(f"Error updating order status: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/users")
async def get_all_users(
    page: int = Query(1, ge=1),
    per_page: int = Query(50, ge=1, le=100)
):
    """Get all users with pagination"""
    try:
        users = await db.get_users(page=page, per_page=per_page)
        return {
            "success": True,
            "message": "Users retrieved successfully",
            "data": users
        }
    except Exception as e:
        logger.error(f"Error getting users: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.put("/api/admin/product-stock")
async def update_product_stock(
    product_id: str,
    stock_quantity: int,
    current_user_id: str = Depends(verify_token)
):
    """Update product stock quantity"""
    try:
        result = await db.update_product_stock(product_id, stock_quantity)
        if result:
            return {
                "success": True,
                "message": "Product stock updated successfully",
                "data": result
            }
        else:
            raise HTTPException(status_code=404, detail="Product not found")
    except Exception as e:
        logger.error(f"Error updating product stock: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.delete("/api/admin/product/{product_id}")
async def delete_product_admin(
    product_id: str,
    current_user_id: str = Depends(verify_token)
):
    """Delete a product (Admin only)"""
    try:
        result = await db.delete_product(product_id)
        if result:
            return {
                "success": True,
                "message": "Product deleted successfully",
                "data": {"deleted": True}
            }
        else:
            raise HTTPException(status_code=404, detail="Product not found")
    except Exception as e:
        logger.error(f"Error deleting product: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/admin/bulk-stock-update")
async def bulk_stock_update(
    action: str,
    current_user_id: str = Depends(verify_token)
):
    """Bulk stock update operations"""
    try:
        if action == "mark_all_out_of_stock":
            result = await db.bulk_update_stock({"stock_quantity": 0})
        elif action == "reset_all_stock":
            result = await db.bulk_update_stock({"stock_quantity": 100})
        else:
            raise HTTPException(status_code=400, detail="Invalid action")
        
        return {
            "success": True,
            "message": f"Bulk {action} completed successfully",
            "data": {"updated_count": result}
        }
    except Exception as e:
        logger.error(f"Error in bulk stock update: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/admin/stock-overview")
async def get_stock_overview():
    """Get comprehensive stock overview"""
    try:
        overview = await db.get_stock_overview()
        return {
            "success": True,
            "message": "Stock overview retrieved successfully",
            "data": overview
        }
    except Exception as e:
        logger.error(f"Error getting stock overview: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/admin/low-stock-products")
async def get_low_stock_products_admin(
    threshold: int = Query(10, ge=1)
):
    """Get products with low stock"""
    try:
        products = await db.get_low_stock_products(threshold)
        return {
            "success": True,
            "message": f"Found {len(products)} low stock products",
            "data": products
        }
    except Exception as e:
        logger.error(f"Error getting low stock products: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/admin/dashboard-stats")
async def get_dashboard_stats():
    """Get comprehensive dashboard statistics"""
    try:
        stats = await db.get_dashboard_stats()
        return {
            "success": True,
            "message": "Dashboard stats retrieved successfully",
            "data": stats
        }
    except Exception as e:
        logger.error(f"Error getting dashboard stats: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Payment Routes
@app.get("/api/payments/crypto/currencies")
async def get_crypto_currencies():
    """Get available cryptocurrency options"""
    try:
        from nowpayments_service import nowpayments_service
        currencies = await nowpayments_service.get_available_currencies()
        return {
            "success": True,
            "message": "Crypto currencies retrieved successfully",
            "data": currencies
        }
    except Exception as e:
        logger.error(f"Error getting crypto currencies: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/payments/crypto/create")
async def create_crypto_payment(payment_request: CryptoPaymentRequest):
    """Create a new cryptocurrency payment"""
    try:
        from nowpayments_service import nowpayments_service
        
        # Get the order to validate
        order = await db.get_order(payment_request.order_id)
        if not order:
            raise HTTPException(status_code=404, detail="Order not found")
        
        # Create payment in NOWPayments with detailed order description
        order_description = f"Order {payment_request.order_id}"
        if order.items:
            product_names = [item.product_name for item in order.items]
            if len(product_names) == 1:
                order_description = f"{product_names[0]} - Premium Subscription"
            else:
                order_description = f"{len(product_names)} Products: {', '.join(product_names[:2])}"
                if len(product_names) > 2:
                    order_description += f" and {len(product_names)-2} more"
        
        payment_data = {
            "order_id": payment_request.order_id,
            "amount": payment_request.amount,
            "price_currency": payment_request.currency,
            "description": order_description
        }
        
        payment_response = await nowpayments_service.create_payment(payment_data)
        
        # Create payment transaction record with external payment ID
        payment_create = PaymentCreate(
            order_id=payment_request.order_id,
            payment_method=PaymentMethod.CRYPTO,
            amount=payment_request.amount,
            currency=payment_request.currency,
            crypto_currency=payment_request.crypto_currency
        )
        
        payment_transaction = await db.create_payment_transaction(payment_create)
        
        # Update payment transaction with external payment ID and status
        payment_id = payment_response.get("id", f"mock_payment_{payment_request.order_id}")
        await db.update_payment_status(
            payment_id,
            PaymentStatus.WAITING,
            payment_response
        )
        
        return {
            "success": True,
            "message": "Crypto payment created successfully",
            "data": {
                "payment_id": payment_id,
                "invoice_url": payment_response.get("invoice_url"),
                "order_id": payment_response.get("order_id"),
                "price_amount": payment_response.get("price_amount"),
                "price_currency": payment_response.get("price_currency")
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating crypto payment: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/payments/{payment_id}/status")
async def get_payment_status(payment_id: str):
    """Get payment status"""
    try:
        from nowpayments_service import nowpayments_service
        
        # Get status from NOWPayments
        payment_status = await nowpayments_service.get_payment_status(payment_id)
        
        # Update local payment record
        await db.update_payment_status(
            payment_id,
            PaymentStatus(payment_status.get("payment_status")),
            payment_status
        )
        
        return {
            "success": True,
            "message": "Payment status retrieved successfully",
            "data": payment_status
        }
    except Exception as e:
        logger.error(f"Error getting payment status: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/orders/{order_id}/status")
async def get_order_status(order_id: str):
    """Get order status with payment details for real-time tracking"""
    try:
        # Get order details
        order = await db.get_order(order_id)
        if not order:
            raise HTTPException(status_code=404, detail="Order not found")
        
        # Get payment details
        payment = await db.db.payments.find_one({"order_id": order_id})
        payment_status = "pending"
        payment_details = {}
        
        if payment:
            payment.pop('_id', None)
            payment_status = payment.get("status", "pending")
            
            # If payment exists, get latest status from NOWPayments
            if payment.get("payment_id") and payment.get("payment_id").startswith("555"):  # Real NOWPayments ID
                try:
                    from nowpayments_service import nowpayments_service
                    latest_status = await nowpayments_service.get_payment_status(payment["payment_id"])
                    payment_status = latest_status.get("payment_status", payment_status)
                    payment_details = latest_status
                    
                    # Update local record if status changed
                    if payment_status != payment.get("status"):
                        await db.update_payment_status(
                            payment["payment_id"],
                            PaymentStatus(payment_status),
                            latest_status
                        )
                        
                        # Update order status based on payment status
                        if payment_status == "finished":
                            await db.db.orders.update_one(
                                {"id": order_id},
                                {"$set": {"status": "confirmed", "payment_status": "completed"}}
                            )
                        elif payment_status in ["failed", "expired"]:
                            await db.db.orders.update_one(
                                {"id": order_id},
                                {"$set": {"status": "cancelled", "payment_status": "failed"}}
                            )
                        
                except Exception as e:
                    logger.error(f"Error getting NOWPayments status: {e}")
        
        # Determine overall order status
        if payment_status == "finished":
            overall_status = "confirmed"
            status_message = "Payment confirmed - Order processing"
        elif payment_status == "confirming":
            overall_status = "confirming"
            status_message = "Payment being confirmed - Please wait"
        elif payment_status in ["failed", "expired"]:
            overall_status = "failed"
            status_message = "Payment failed"
        elif payment_status == "waiting":
            overall_status = "waiting_payment"
            status_message = "Waiting for payment confirmation"
        else:
            overall_status = "pending"
            status_message = "Order pending"
        
        return {
            "success": True,
            "data": {
                "order_id": order_id,
                "order_status": overall_status,
                "payment_status": payment_status,
                "status_message": status_message,
                "order_details": {
                    "total_amount": order.total_amount,
                    "currency": getattr(order, 'currency', 'INR'),
                    "payment_method": order.payment_method,
                    "items": [item.dict() for item in order.items]
                },
                "payment_details": payment_details,
                "created_at": order.created_at.isoformat() if hasattr(order.created_at, 'isoformat') else str(order.created_at)
            }
        }
        
    except Exception as e:
        logger.error(f"Error getting order status: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/payments/{payment_id}/order")
async def get_order_by_payment_id(payment_id: str):
    """Find order by NOWPayments payment ID"""
    try:
        # Find payment record by external payment ID
        payment = await db.db.payments.find_one({"payment_id": payment_id})
        if not payment:
            # Try to find by gateway response containing this ID
            payment = await db.db.payments.find_one({"gateway_response.id": payment_id})
        
        if payment:
            payment.pop('_id', None)
            return {
                "success": True,
                "data": {
                    "order_id": payment["order_id"],
                    "payment_id": payment_id,
                    "status": payment.get("status", "pending")
                }
            }
        else:
            return {
                "success": False,
                "message": "Payment not found"
            }
    except Exception as e:
        logger.error(f"Error finding order by payment ID: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/payments/nowpayments/ipn")
async def handle_nowpayments_ipn(request: Request):
    """Handle NOWPayments IPN callback"""
    try:
        from nowpayments_service import nowpayments_service
        
        # Get request data
        payload = await request.json()
        signature = request.headers.get("x-nowpayments-sig")
        
        # Validate signature
        if not nowpayments_service.validate_ipn_signature(payload, signature):
            raise HTTPException(status_code=401, detail="Invalid signature")
        
        # Process IPN
        ipn_data = await nowpayments_service.process_ipn_callback(payload)
        
        # Update payment status
        await db.update_payment_status(
            ipn_data["payment_id"],
            PaymentStatus(ipn_data["status"]),
            payload
        )
        
        # Update order status based on payment status
        if ipn_data["status"] == "finished":
            await db.update_order_status(ipn_data["order_id"], OrderStatus.COMPLETED)
            await db.update_order_payment_status(ipn_data["order_id"], PaymentStatus.FINISHED)
        elif ipn_data["status"] in ["failed", "expired"]:
            await db.update_order_status(ipn_data["order_id"], OrderStatus.CANCELLED)
            await db.update_order_payment_status(ipn_data["order_id"], PaymentStatus.FAILED)
        
        return {"status": "OK"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error handling NOWPayments IPN: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Health check
@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}

# Root endpoint
@app.get("/api/")
async def root():
    """Root endpoint"""
    return {
        "message": "Premium Subscription Shop API",
        "version": "1.0.0",
        "status": "running"
    }

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    await db.close()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)